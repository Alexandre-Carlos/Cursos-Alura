﻿namespace Humanizer.Localisation.NumberToWords
{
    internal class FrenchSwissNumberToWordsConverter : FrenchNumberToWordsConverterBase
    {
    }
}