﻿using System.Resources;

[assembly: NeutralResourcesLanguage("en")]
